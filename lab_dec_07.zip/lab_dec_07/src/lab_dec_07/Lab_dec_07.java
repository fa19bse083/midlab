
package lab_dec_07;


public class Lab_dec_07 {

 
    public static void main(String[] args) {
     
    }
    
}
