/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_dec_07;

public abstract class StateManagerImpl {
	
	protected StateManager state;

	protected StateManagerImpl(StateManager state) {
		this.state = state;
	}

	abstract public boolean setState();
}
