
package lab_dec_07;

public class AccountHolder implements AccountHoldersInterface {
    String name,email,age;
    
    AccountHolder(String name,String email, String age){
    this.name=name;
    this.email=email;
    this.age = age;
    }
    
    @Override
    public void sendNotification() {
        
    }
    
}
