
package lab_dec_07;

public class BankAccount {
    Accountholder collection[];
    int index=0;
    
    void add (String mail,String name,String age)
    {
        collection[index] = new Accountholder(mail,name,age);
        index++;
    }
    void remove(Accounthloder account)
    {
        for(int i=0;i<index;i++)
        {
            if[(collection[i]=account)
            {
                for(int j=i;j<index;j++)
                {
                    collection[j]=collection[j+i];
                }
            }
            else
            {
                    System.out.println("Account is not found");
                    }
        }
    }
    
void sendNotification(){
    for(int i=0;i<index;i++){
    collection[index].sendNotification();
    }
    }
    
  
    @Override
    public boolean setState()
    {
        StateManagerImpl isState;
    if(!state)
    {
    isState = new StateDectector(new ActiveState());
    state = isState.setState();
    }
    else
    {
    isState = new StateDectector(new DeActiveState());
    state = isState.setState();
    }
    return state;
    }
        
}

